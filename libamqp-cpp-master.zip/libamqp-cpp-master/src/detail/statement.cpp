#include "statement.h"

namespace amqpp
{
namespace detail
{

} // namespace detail
} // namespace amqpp